document.getElementById("licenciaForm").addEventListener("submit", async function (event) {
  event.preventDefault();

  const tipoDocumento = document.getElementById("tipoDocumento").value;
  const numeroDocumento = document.getElementById("numeroDocumento").value;
  const url = `http://145.223.79.189:3000/api/consultar-licencia?tipo_documento=${tipoDocumento}&numero_documento=${numeroDocumento}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.success) {
      const { apellido, nombre, numero_expediente, clase, categoria, fecha_expedicion, fecha_revalidacion, restricciones } = data.data;

      document.getElementById("resultado").innerHTML = `
       <div class="resultado-content">
        <h2 class="resultado-title">Consulta de Licencia de conducir </h2>
        <div>
            <span>Apellido:</span> ${apellido || "N/A"}
        </div>
        <div>
            <span>Nombre:</span> ${nombre || "N/A"}
        </div>
        <div>
            <span>Número de Documento:</span> ${numeroDocumento}
        </div>
        <div>
            <span>Clase - Categoría:</span> ${clase || "N/A"} - ${categoria || "N/A"}
        </div>
        <div>
            <span>Fecha de Expedición:</span> ${fecha_expedicion || "N/A"}
        </div>
        <div>
            <span>Fecha de Revalidación:</span> ${fecha_revalidacion || "N/A"}
        </div>
        <div>
            <span>Número de Expediente:</span> ${numero_expediente || "N/A"}
        </div>
        <div>
            <span>Restricciones:</span> ${restricciones || "SIN RESTRICCIONES"}
        </div>
    </div>
          
      <div class="footer">
          <p>Su licencia se encuentra <strong>VIGENTE</strong> y en proceso de migración al MTC</p>
          </div>
      <div class="icono-estado">
          <img src="1.jpg" alt="Estado Feliz" class="icono-feliz" style="width: 250px; height: 250px;">
        </div>
        </div>`;
    } else {
     document.getElementById("resultado").innerHTML =`
      <div class="resultado-content2">
       <img src="2.jpg" alt="Estado Feliz" class="icono-triste" style="width: 250px; height: 250px;">
       </div>`;
    }
  } catch (error) {
    console.error("Error en la consulta:", error);
    document.getElementById("resultado").innerHTML = `<p>Error en la consulta de la licencia: ${error.message}</p>`;
  }
});
document.addEventListener("DOMContentLoaded", function () {
  abrirPopup(); // Llama a abrirPopup al cargar la página
});

function abrirPopup() {
  document.getElementById("popup").classList.add("show"); // Muestra el popup
}

function cerrarPopup() {
  document.getElementById("popup").classList.remove("show"); // Oculta el popup
}
