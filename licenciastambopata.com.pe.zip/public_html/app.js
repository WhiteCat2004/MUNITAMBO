const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Ruta de prueba para verificar si el servidor está activo
app.use(express.static("public"));

// Configuración de CORS para permitir conexiones desde cualquier origen
app.use(cors({
    origin: '*', // Permite todas las conexiones (útil para pruebas locales)
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type']
}));

app.use(bodyParser.json());

// Configuración de la base de datos MySQL en Hostinger
const dbConfig = {
    host: 'srv1529.hstgr.io',
    user: 'u580509106_devloper',
    password: 'Devloper2.',
    database: 'u580509106_licencias',
    connectTimeout: 10000
};

let db;

// Función para manejar la conexión y reconexión a la base de datos
function handleDisconnect() {
    db = mysql.createConnection(dbConfig);

    db.connect((err) => {
        if (err) {
            console.error('Error al conectar con la base de datos:', err);
            setTimeout(handleDisconnect, 2000); // Reintenta la conexión después de 2 segundos
        } else {
            console.log('Conectado a la base de datos MySQL en Hostinger');
        }
    });

    db.on('error', (err) => {
        console.error('Error en la base de datos:', err);
        if (err.code === 'PROTOCOL_CONNECTION_LOST' || err.code === 'ECONNRESET') {
            handleDisconnect(); // Reconecta automáticamente en caso de pérdida de conexión
        } else {
            throw err;
        }
    });
}

// Inicializa la conexión
handleDisconnect();

// Ruta para consultar una licencia, acepta tanto GET como POST
app.all('/api/consultar-licencia', (req, res) => {
    const tipoDocumento = req.method === 'POST' ? req.body.tipo_documento : req.query.tipo_documento;
    const numeroDocumento = req.method === 'POST' ? req.body.numero_documento : req.query.numero_documento;

    if (!tipoDocumento || !numeroDocumento) {
        return res.status(400).json({
            success: false,
            message: 'Faltan parámetros: tipo_documento y numero_documento son necesarios'
        });
    }

    const query = 'SELECT * FROM licencias WHERE tipo_documento = ? AND numero_documento = ?';

    db.query(query, [tipoDocumento, numeroDocumento], (err, result) => {
        if (err) {
            console.error('Error en la consulta de la base de datos:', err);
            return res.status(500).json({ success: false, message: 'Error en la consulta de la base de datos' });
        }
        
        if (result.length > 0) {
            res.json({
                success: true,
                message: 'Licencia encontrada 😊',
                data: result[0],
            });
        } else {
            res.json({ success: false, message: 'No se encontró la licencia 😢' });
        }
    });
});

// Enviar una consulta periódica para mantener la conexión activa
setInterval(() => {
    if (db) {
        db.query('SELECT 1', (err) => {
            if (err) console.error('Error en la consulta de mantenimiento:', err);
        });
    }
}, 5000); // Envía una consulta cada 5 segundos

// Iniciar el servidor
const PORT = 3006; // Cambia al puerto específico si Hostinger proporciona uno diferente
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});
